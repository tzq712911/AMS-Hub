use std::{rc::Rc, cell::RefCell, time::Instant};
use slint::{ComponentHandle, Rgb8Pixel, platform::{Platform, software_renderer::{MinimalSoftwareWindow, RepaintBufferType}}};
slint::include_modules!();

struct OffscreenPlatform { window: Rc<MinimalSoftwareWindow>, started: Instant }
impl Platform for OffscreenPlatform {
    fn create_window_adapter(&self) -> Result<Rc<dyn slint::platform::WindowAdapter>, slint::PlatformError> { Ok(self.window.clone()) }
    fn duration_since_start(&self) -> std::time::Duration { self.started.elapsed() }
}

fn click(window: &slint::Window, x: f32, y: f32) {
    use slint::platform::{WindowEvent, PointerEventButton};
    let position = slint::LogicalPosition::new(x, y);
    window.dispatch_event(WindowEvent::PointerMoved { position });
    window.dispatch_event(WindowEvent::PointerPressed { position, button: PointerEventButton::Left });
    window.dispatch_event(WindowEvent::PointerReleased { position, button: PointerEventButton::Left });
    slint::platform::update_timers_and_animations();
}

fn render(ui: &ConsolePreview, window: &MinimalSoftwareWindow, output: &str, name: &str) -> Result<(), Box<dyn std::error::Error>> {
    slint::platform::update_timers_and_animations();
    ui.window().request_redraw();
    let mut pixels = vec![Rgb8Pixel::default(); 480 * 320];
    assert!(window.draw_if_needed(|renderer| { renderer.render(&mut pixels, 480); }));
    let bytes: Vec<u8> = pixels.into_iter().flat_map(|p| [p.r, p.g, p.b]).collect();
    image::save_buffer(std::path::Path::new(output).join(name), &bytes, 480, 320, image::ColorType::Rgb8)?;
    println!("Rendered {name}: 480x320, simulated data");
    Ok(())
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let output = std::env::args().nth(1).unwrap_or_else(|| "screenshots".into());
    std::fs::create_dir_all(&output)?;
    let window = MinimalSoftwareWindow::new(RepaintBufferType::NewBuffer);
    slint::platform::set_platform(Box::new(OffscreenPlatform { window: window.clone(), started: Instant::now() }))?;
    let ui = ConsolePreview::new()?;
    let weak = ui.as_weak();
    ui.global::<AppBackend>().on_get_console_presets(move || weak.unwrap().get_demo_presets());
    let weak = ui.as_weak();
    ui.global::<AppBackend>().on_get_slot_display(move |_| weak.unwrap().get_demo_slot());
    ui.global::<AppBackend>().on_get_console_calibrations(|_, _| Default::default());
    let submissions = Rc::new(RefCell::new(Vec::new()));
    let captured = submissions.clone();
    ui.global::<AppBackend>().on_configure_console_slot(move |tray, preset, material, color, calibration| {
        captured.borrow_mut().push((tray, preset.to_string(), material.to_string(), color.to_string(), calibration));
        "".into()
    });
    ui.window().set_size(slint::PhysicalSize::new(480, 320));
    ui.show()?;
    for (mode, name) in [(0, "home.png"), (1, "editor.png")] {
        ui.set_preview_mode(mode);
        render(&ui, &window, &output, name)?;
    }
    click(ui.window(), 300., 110.);
    render(&ui, &window, &output, "materials.png")?;
    click(ui.window(), 200., 80.);
    click(ui.window(), 145., 146.);
    render(&ui, &window, &output, "palette.png")?;
    click(ui.window(), 180., 90.);
    click(ui.window(), 420., 289.);
    assert_eq!(submissions.borrow().as_slice(), &[(0, "GFA00".into(), "PLA".into(), "71CCE1FF".into(), -1)]);
    click(ui.window(), 420., 289.);
    assert_eq!(submissions.borrow().len(), 1, "Repeated confirmation must not submit twice");
    println!("PASS: material picker, palette selection, outgoing metadata, duplicate-submit guard");
    ui.set_preview_mode(2);
    render(&ui, &window, &output, "registration.png")?;
    ui.set_preview_mode(3);
    render(&ui, &window, &output, "settings.png")?;
    Ok(())
}
