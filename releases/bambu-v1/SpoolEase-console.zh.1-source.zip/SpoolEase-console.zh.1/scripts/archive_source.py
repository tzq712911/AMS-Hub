"""Package reproducible sources and licenses, excluding local build caches."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
output = root / "dist/SpoolEase-console.zh.1-source.zip"
output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in {"target", "dist", ".git", "__pycache__"} for part in relative.parts):
            continue
        archive.write(path, Path("SpoolEase-console.zh.1") / relative)
print(output)
